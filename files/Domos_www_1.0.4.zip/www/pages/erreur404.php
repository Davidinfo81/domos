<br />
<span class="titre_page">ERREUR 404</span>
<br />
<?php
warning("Erreur : Page non trouv�e !</h2><p style=\"text-align:center\">utilises les menus � gauche.</p>");
?>

